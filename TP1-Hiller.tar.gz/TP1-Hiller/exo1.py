from os import chdir
import os

#importation du module graphique
import cng




x1,x2,y1,y2 = None, None, None, None

def grosPoint(x,y) :
	cng.box(x-2,y-2,x+2,y+2)

def initWindow(px1,py1,px2,py2):
	global x1,x2,y1,y2 
	x1, x2, y1, y2 = px1, px2, py1 ,py2
	cng.init_window(pnom='Ecran', pla=800, pha=600, color='white')
	cng.rectangle(x1,y1,x2,y2)
	 
	 
def mooveWindow(x,y):
	
	#cng.clear_screen()
	cng.rectangle(x1 + x, y1 + y, x2 +x, y2 + y)
	  

def displayPoint(px,py, pfx1,pfy1,pfx2,pfy2, pvx1,pvy1,pvx2,pvy2):
	cng.init_window('Exercice2', 800, 600, 'white')
	cng.rectangle(pvx1,pvy1,pvx2,pvy2)
	
	Xdc = pvx2 - pvx1
	Ydc = pvy2 - pvy1
	Xwc = pfx2 - pfx1
	Ywc = pfy2 - pfy1
	
	xScreen = px * (Xdc/Xwc) - pfx1 * (Xdc/Xwc) + pvx1
	yScreen = py * (Ydc/Ywc) - pfy1 * (Ydc/Ywc) + pvy1
	
	
	grosPoint(xScreen,yScreen)


def calculPoint(px,py, pfx1,pfy1,pfx2,pfy2, pvx1,pvy1,pvx2,pvy2):
	
	Xdc = pvx2 - pvx1
	Ydc = pvy2 - pvy1
	Xwc = pfx2 - pfx1
	Ywc = pfy2 - pfy1
	
	xScreen = px * (Xdc/Xwc) - pfx1 * (Xdc/Xwc) + pvx1
	yScreen = py * (Ydc/Ywc) - pfy1 * (Ydc/Ywc) + pvy1
	
	print "x = %d et y = %d" % (xScreen, yScreen)
	
	 
def getLines(nameFile):
	fi = open(nameFile,'r')
	lignes = fi.readlines()
	fi.close
	return lignes
	
def transformPoints(nameFile):
	pointsList = []
	points = getLines(nameFile)
	for filePoint in points:
		splitTab = filePoint.split()
		x = int(splitTab[0])
		y = int(splitTab[1])
		pointsList.append(x)
		pointsList.append(y)
	print(pointsList)
	
	taille = len(pointsList)
	i=0
	while i < taille -1:
		calculPoint(pointsList[i],pointsList[i+1], 2,2,38,56,  30,50,468,743)
		i += 2
	
	

if __name__ == "__main__" :
	#initWindow(50,50,200,200)
	#mooveWindow(50,100)
	
	displayPoint(5,3,  2,2,10,8,  50,50,250,350)
	
	transformPoints('file')
	
	
	cng.main_loop()
